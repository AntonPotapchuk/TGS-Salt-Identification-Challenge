import os
import numpy as np

from common.constants import MAX_WIDTH_WITHOUT_PADDING
from keras.preprocessing.image import img_to_array, load_img
from skimage.transform import resize


def get_padding_width(width, max_width):
    return int((width - max_width) / 2)


def transform_predictions(prediction, original_size):
    size = prediction.shape[0]
    pad_width = get_padding_width(size, MAX_WIDTH_WITHOUT_PADDING)
    prediction = prediction[pad_width:-pad_width, pad_width:-pad_width]
    prediction = resize(prediction, original_size, mode='constant', preserve_range=True)
    return prediction


def process_image(img, width, preprocess_func=None):
    img = img_to_array(img)
    if width <= MAX_WIDTH_WITHOUT_PADDING:
        img = resize(img, (width, width), mode='constant', preserve_range=True)
    else:
        img = resize(img, (MAX_WIDTH_WITHOUT_PADDING, MAX_WIDTH_WITHOUT_PADDING), mode='constant', preserve_range=True)
        pad_width = get_padding_width(width, MAX_WIDTH_WITHOUT_PADDING)
        img = np.pad(img, mode='reflect', pad_width=[(pad_width, pad_width), (pad_width, pad_width), (0, 0)])
    if preprocess_func is not None:
        img = preprocess_func(img)
    return img


def get_dataset(ids, img_folder, mask_folder, image_size, is_test=False, preprocess_func=None):
    X = []
    if not is_test:
        Y = np.zeros((len(ids), image_size, image_size, 1), dtype=np.bool)
    for n, id_ in enumerate(ids):
        img = load_img(os.path.join(img_folder, id_))
        img = process_image(img, image_size, preprocess_func)
        X.append(img)
        if not is_test:
            mask = load_img(os.path.join(mask_folder, id_))[:,:,1]
            Y[n] = process_image(mask, image_size, None)
    X = np.nan_to_num(np.array(X))
    if is_test:
        return X
    return X, Y
