class ModelBuilderBase(object):
    def get_model(self):
        raise NotImplementedError("")

    def get_size(self, size):
        raise NotImplementedError("")

    def get_image_preprocessor(self):
        return None